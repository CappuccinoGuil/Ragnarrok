﻿using UnityEngine;
using System.Collections;

public class impulseScript : MonoBehaviour {

	public Rigidbody2D body;

	// Use this for initialization
	void Start () {
//		body.AddForce(-transform.forward * 500f);
//		body.useAutoMass = true;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

}
